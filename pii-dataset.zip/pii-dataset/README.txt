PII document images
===================

200 synthetic document images (73 id cards, 70 invoices, 57 forms;
166 train / 19 validation / 15 test) with labelled PII bounding boxes.

Source:  https://huggingface.co/datasets/hussain-khalid/pii-dataset
Licence: CC0-1.0

All names, addresses, emails, phone numbers, ID numbers and dates of birth are
synthetic. The dataset contains no real person's data.

images/  The document images (PNG), unchanged from the dataset.
data/    The label files (Parquet), one per split, unchanged from the dataset.
         Each row is one image: id, image, width, height, doc_type, and
         fields, a JSON list of {label, text, bbox: [x0, y0, x1, y1]}.
